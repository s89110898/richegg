<?php

session_start();// 啟用session  可以拿伺服器端的東西
require("User.php");


if(! isset($_POST["act"])) {
	exit(0); //離開PHP程式了，所以下面的程式都不會執行
}
$act =$_POST["act"];

switch($act) {
	case "purchase":
		$quantity=$_POST['quantity'];
		$price1=$_POST['price'];
		echo '接收到的quantity為: '.$quantity;
		echo '接收到的price為: '.$price1;
		//1. $ 「先確認錢夠不夠」    先選使用的錢  然後跟 $quantity * $price1
		// model
		$sql1 =" select Cash from user where user_id = '$uID' ";
		$result1 = mysqli_query($conn,$sql1); //執行
		/* while ($row1=mysqli_fetch_assoc($result1) ){ //抓一筆  給row
			//現在沒用，以前是利用while在裡面在做，印出一筆一筆的資料，
			} 	*/
		$row1=mysqli_fetch_assoc($result1);//我們只有一筆，直接抓就好
		// 這一筆是顯示Cash
	
		if ($row1['Cash'] >= ($quantity * $price1))
			//Cash - ($quantity * $price1)
			$sql2 = "update user set Cash = ("+$row1['Cash']+"-("+$quantity+" * "+$price1+")) ";
			$result2 = mysqli_query($conn,$sql2); //執行
		else 
			echo "金錢不足";

		// 如果 buy1  會做些什麼？      
		// 2. 處理訂單資料
		$newT = date("Y-m-d H:i:s",strtotime("+1 minutes"));//成效未知
		$sql3 = " insert into orderr (pID, number, aTime, cash ) values (1, '$quantity', '$newT', ("+$price+"*"+$quantity+"))";
		$result3 = mysqli_query($conn,$sql3); //執行

		// 所以頁面的填寫類似表單那類，我們做傳值的處理
		
		// 到貨時間 = 現在時間+固定周期
		// 3. 時間到了  總店的甲商品數量變更
		//先抓原本p1Num的值
		//再下以下的SQL(未完成)
		$sql4 = "UPDATE mainstore SET p1Num = "+$row2['Cash']+"  '$quantity'";

		//可用case add的方式處理新增分店嗎？ //店面id  產品id  上限  庫存
	
	case "login":
		$loginName = $_POST['id'];
		$password = $_POST['pwd'];
		$role=checkUser($loginName, $password);
		if ( $role> -1 ) { // User.php內設定  -1代表登入失敗
			//set login session mark
			$_SESSION['uID'] = $loginName;
			$_SESSION['role'] = $role;
			echo "login OK<br>";
			echo "<a href='./'>Home</a>";
		} else {
			//set login mark to empty
			$_SESSION['uID'] = "";
			$_SESSION['role'] = -1;
			echo "Login failed.<br>";
			echo "<a href='loginForm.php'>login</a>";
		}   
}
?>