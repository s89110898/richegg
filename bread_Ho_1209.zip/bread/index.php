<?php
session_start();
require("dbconnect.php");
if (! isset($_SESSION["uID"]))
	$_SESSION["uID"] = "";
//echo $_SESSION["uID"];
if ( $_SESSION["uID"] < " ") {
	//header("Location: login.php");
	echo "Please Login. <a href='loginForm.php'>Login</a>";
	exit(0);
}
?>
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="jquery.js"></script>
<script language="javascript">

</script>
</head>

<table width="450" border="1">
<tr id="">
<td><input type="button" value="分店一" onclick="location.href='要前往的網頁連結'"></td>
<td><input type="button" value="分店二" onclick="location.href='要前往的網頁連結'"></td>
<td><input type="button" value="新增分店"></td>

<td rowspan = 3> 總店庫存商品</td>
<td><input type="button" value="訂購甲商品" onclick="location.href='order.php'"></td>
</tr>
<tr>
<td colspan="3"></td>

<td><input type="button" value="訂購乙商品" onclick="location.href='要前往的網頁連結'"></td>
</tr>
<tr>
<td colspan="3">$$$</td>

<td><input type="button" value="訂購丙商品" onclick="location.href='要前往的網頁連結'"></td>
</tr>
</table>