<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="jquery.js"></script>
<script language="javascript">
</script>
</head>

<!-- form 把 name 跟  value都post走 -->
<!-- html是靜態  php是動態 -->
<form action="controller.php" method="post">
<input type="hidden" name="act" value="purchase"> 

目前進貨價格：<?php
$price1 = rand(50,80);
echo $price1;
echo '<br>';
?>
<input type="hidden" name="price" value="<?php  echo $price1 ?>">
輸入進貨量：<input type="text" name="quantity"><br>
<input type="submit" value="送出表單"> <!--  submit不用傳-->

</form>